<!-- bootsrap css -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<div class="card text-center" style="text-align: center">
    <div class="card-header">
        <img src="cid:image_cid2">
    </div>
    <div class="card-body" style="text-align: center; ">
        <h3 class="card-title"><b>Halo, Berikut Kami Kabarkan Tentang' . $this->message . '</b></h3>
        <p class="card-text">
        <p>Hi ' . $this->namaUser . ', Kami dari tim <b>Wikikos</b></p>

        <p>Kami Ingin Mengabarkan Tentang ' . $this->message . '</p>

        <br>

        <p>Nama : <b>Kosan Buhaji</b></p>
        <p>status : <b>Diterima</b></p>

        <br>

        <p><b>Wikikos</b> akan selalu membuatmu aman dan nyaman, cari kos ya Wikikos.</p>
        <p>Wikikos solusi bagi para pencari kos.</p>
        </p>
    </div>
    <br>
    <div class="card-footer text-muted" style="text-align: center">
        Terima Kasih sudah membaca email kami!.<br>
        Customer Care +6288000889911 24/7 services
    </div>
</div>';