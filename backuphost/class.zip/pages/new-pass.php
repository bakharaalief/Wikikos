<div class="resetpass">
    <div id="resetbyemail" class="container">
        <div class="row align-items-center">
            <!-- ini adalah page form untuk pengisian pass baru -->
            <!-- maintenance development dengan diarahkan ke login -->

            <form action="./pages/login.php" method="Post">
                <h1>Input Password baru anda</h1>
                <input type="password" class="form-control" placeholder="Masukkan Password baru anda disini" name="password" required>
                <button type="submit" class="submit">Submit</button>
            </form>
        </div>
    </div>
</div>