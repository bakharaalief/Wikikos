<div class="resetpass">
    <div id="resetbyemail" class="container">
        <div class="row align-items-center">
            <!-- ini adalah page form untuk pengisian reset pass -->
            <form action="./action/search/search-config.php" method="Post">
                <h1>Input pencarian data yang diinginkan</h1>
                <input type="keywords" class="form-control" placeholder="Masukkan keywords anda" name="keywords" required>
                <button type="submit" class="submit">cari</button>
            </form>
        </div>
    </div>
</div>