<div class="resetpass">
    <div id="resetbyemail" class="container">
        <div class="row align-items-center">
            <!-- ini adalah page form untuk pengisian reset pass -->
            <form action="?p=reset-pass-action" method="Post">
                <h1>Input E-Mail</h1>
                <input type="email" class="form-control" placeholder="Masukkan Email anda disini" name="email" required>
                <button type="submit" class="submit">Submit</button>
            </form>
        </div>
    </div>
</div>